#!/usr/bin/env python3
"""
Research PDF Generator - Creates professional technical research reports from markdown input

This script generates a formatted PDF with the following sections:
- Cover page with title and metadata
- Executive Summary
- Table of Contents (auto-generated)
- Main content sections
- 3-line acrostic poem based on keywords
- References/Bibliography

Requirements:
    pip install reportlab markdown
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Tuple

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, PageBreak,
        Table, TableStyle, KeepTogether
    )
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
    from reportlab.pdfgen import canvas
except ImportError:
    print("Error: reportlab is required. Install with: pip install reportlab")
    sys.exit(1)

try:
    import markdown
except ImportError:
    print("Error: markdown is required. Install with: pip install markdown")
    sys.exit(1)


class ResearchPDFGenerator:
    """Generates professional research PDFs from markdown content"""

    def __init__(self, output_path: str, page_size=letter):
        self.output_path = output_path
        self.page_size = page_size
        self.width, self.height = page_size
        self.styles = self._create_styles()
        self.story = []
        self.toc_entries = []

    def _create_styles(self) -> Dict:
        """Create minimal/professional document styles"""
        styles = getSampleStyleSheet()

        # Custom styles for professional look
        custom_styles = {
            'CustomTitle': ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=28,
                textColor=colors.HexColor('#1a1a1a'),
                spaceAfter=30,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold'
            ),
            'CustomHeading1': ParagraphStyle(
                'CustomHeading1',
                parent=styles['Heading1'],
                fontSize=18,
                textColor=colors.HexColor('#2c3e50'),
                spaceBefore=20,
                spaceAfter=12,
                fontName='Helvetica-Bold',
                borderWidth=0,
                borderColor=colors.HexColor('#34495e'),
                borderPadding=8,
            ),
            'CustomHeading2': ParagraphStyle(
                'CustomHeading2',
                parent=styles['Heading2'],
                fontSize=14,
                textColor=colors.HexColor('#34495e'),
                spaceBefore=14,
                spaceAfter=8,
                fontName='Helvetica-Bold'
            ),
            'CustomHeading3': ParagraphStyle(
                'CustomHeading3',
                parent=styles['Heading3'],
                fontSize=12,
                textColor=colors.HexColor('#555555'),
                spaceBefore=10,
                spaceAfter=6,
                fontName='Helvetica-Bold'
            ),
            'CustomBody': ParagraphStyle(
                'CustomBody',
                parent=styles['BodyText'],
                fontSize=11,
                leading=16,
                textColor=colors.HexColor('#333333'),
                alignment=TA_JUSTIFY,
                spaceAfter=8
            ),
            'CustomCode': ParagraphStyle(
                'CustomCode',
                parent=styles['Code'],
                fontSize=9,
                leading=12,
                textColor=colors.HexColor('#c7254e'),
                backColor=colors.HexColor('#f9f2f4'),
                leftIndent=20,
                rightIndent=20,
                spaceAfter=10
            ),
            'TOCEntry': ParagraphStyle(
                'TOCEntry',
                parent=styles['Normal'],
                fontSize=11,
                leading=16,
                leftIndent=0,
                spaceAfter=4
            ),
            'Acrostic': ParagraphStyle(
                'Acrostic',
                parent=styles['Normal'],
                fontSize=13,
                leading=20,
                textColor=colors.HexColor('#2c3e50'),
                leftIndent=30,
                fontName='Helvetica-Oblique',
                spaceAfter=6
            ),
        }

        # Add custom styles to the existing stylesheet
        for name, style in custom_styles.items():
            styles.add(style)

        return styles

    def _parse_markdown_metadata(self, content: str) -> Tuple[Dict, str]:
        """Extract YAML frontmatter if present"""
        metadata = {}

        # Check for YAML frontmatter
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                frontmatter = parts[1].strip()
                content = parts[2].strip()

                for line in frontmatter.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        metadata[key.strip()] = value.strip()

        return metadata, content

    def _parse_markdown_sections(self, content: str) -> List[Dict]:
        """Parse markdown content into sections"""
        sections = []
        current_section = None
        lines = content.split('\n')

        for line in lines:
            # Check for headings
            heading_match = re.match(r'^(#{1,3})\s+(.+)$', line)

            if heading_match:
                # Save previous section
                if current_section:
                    sections.append(current_section)

                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()

                current_section = {
                    'level': level,
                    'title': title,
                    'content': []
                }
            elif current_section:
                current_section['content'].append(line)

        # Add last section
        if current_section:
            sections.append(current_section)

        return sections

    def _add_cover_page(self, title: str, metadata: Dict):
        """Add professional cover page"""
        # Title
        self.story.append(Spacer(1, 2*inch))
        self.story.append(Paragraph(title, self.styles['CustomTitle']))
        self.story.append(Spacer(1, 0.3*inch))

        # Subtitle or description
        if 'subtitle' in metadata:
            subtitle_style = ParagraphStyle(
                'Subtitle',
                parent=self.styles['Normal'],
                fontSize=14,
                textColor=colors.HexColor('#555555'),
                alignment=TA_CENTER,
                spaceAfter=20
            )
            self.story.append(Paragraph(metadata['subtitle'], subtitle_style))
            self.story.append(Spacer(1, 0.5*inch))

        # Metadata table
        meta_data = [
            ['Author:', metadata.get('author', 'N/A')],
            ['Date:', metadata.get('date', datetime.now().strftime('%Y-%m-%d'))],
            ['Version:', metadata.get('version', '1.0')],
        ]

        meta_table = Table(meta_data, colWidths=[1.5*inch, 3*inch])
        meta_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#333333')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))

        self.story.append(Spacer(1, inch))
        self.story.append(meta_table)
        self.story.append(PageBreak())

    def _add_toc(self):
        """Add table of contents"""
        self.story.append(Paragraph("Table of Contents", self.styles['CustomHeading1']))
        self.story.append(Spacer(1, 0.2*inch))

        for entry in self.toc_entries:
            level = entry['level']
            title = entry['title']
            indent = (level - 1) * 20

            toc_style = ParagraphStyle(
                'TOCEntry',
                parent=self.styles['TOCEntry'],
                leftIndent=indent
            )

            # Add dot leaders manually (simplified)
            prefix = "  " * (level - 1) + ("• " if level > 1 else "")
            self.story.append(Paragraph(f"{prefix}{title}", toc_style))

        self.story.append(PageBreak())

    def _add_section(self, section: Dict):
        """Add a content section"""
        level = section['level']
        title = section['title']
        content = '\n'.join(section['content']).strip()

        # Add to TOC
        self.toc_entries.append({'level': level, 'title': title})

        # Add heading
        heading_style = self.styles.get(f'CustomHeading{level}', self.styles['CustomHeading3'])
        self.story.append(Paragraph(title, heading_style))

        # Process content
        if content:
            # Split into paragraphs
            paragraphs = content.split('\n\n')

            for para in paragraphs:
                para = para.strip()
                if not para:
                    continue

                # Check for code blocks
                if para.startswith('```') and para.endswith('```'):
                    code = para.strip('`').strip()
                    # Remove language identifier if present
                    if '\n' in code:
                        lines = code.split('\n')
                        if not lines[0].strip().startswith(' '):
                            code = '\n'.join(lines[1:])
                    self.story.append(Paragraph(code.replace('\n', '<br/>'), self.styles['CustomCode']))

                # Check for bullet lists
                elif para.startswith('- ') or para.startswith('* '):
                    items = para.split('\n')
                    for item in items:
                        if item.strip().startswith(('- ', '* ')):
                            clean_item = item.strip()[2:].strip()
                            bullet_style = ParagraphStyle(
                                'Bullet',
                                parent=self.styles['CustomBody'],
                                leftIndent=20,
                                bulletIndent=10
                            )
                            self.story.append(Paragraph(f"• {clean_item}", bullet_style))

                # Regular paragraph
                else:
                    # Simple markdown processing
                    para = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', para)  # Bold
                    para = re.sub(r'\*(.+?)\*', r'<i>\1</i>', para)  # Italic
                    para = re.sub(r'`(.+?)`', r'<font face="Courier" color="#c7254e">\1</font>', para)  # Inline code

                    self.story.append(Paragraph(para, self.styles['CustomBody']))

        self.story.append(Spacer(1, 0.15*inch))

    def _generate_acrostic(self, keywords: List[str]) -> List[str]:
        """Generate 3-line acrostic from keywords (placeholder for AI generation)"""
        # In practice, this would call an AI API or use the provided acrostic
        # For now, return a template
        acrostic_lines = []
        for i, keyword in enumerate(keywords[:3], 1):
            if keyword:
                first_letter = keyword[0].upper()
                acrostic_lines.append(f"{first_letter} - {keyword} brings innovation to our research")

        return acrostic_lines

    def _add_acrostic_section(self, keywords: List[str]):
        """Add 3-line acrostic poem section"""
        self.story.append(Paragraph("Key Insights", self.styles['CustomHeading1']))
        self.story.append(Spacer(1, 0.1*inch))

        acrostic_lines = self._generate_acrostic(keywords)

        for line in acrostic_lines:
            self.story.append(Paragraph(line, self.styles['Acrostic']))

        self.story.append(Spacer(1, 0.3*inch))

    def _add_references(self, references: List[str]):
        """Add references/bibliography section"""
        self.story.append(PageBreak())
        self.story.append(Paragraph("References", self.styles['CustomHeading1']))
        self.story.append(Spacer(1, 0.1*inch))

        ref_style = ParagraphStyle(
            'Reference',
            parent=self.styles['CustomBody'],
            leftIndent=20,
            firstLineIndent=-20,
            spaceAfter=10
        )

        for i, ref in enumerate(references, 1):
            self.story.append(Paragraph(f"[{i}] {ref}", ref_style))

    def generate(self, markdown_content: str, keywords: List[str] = None, references: List[str] = None):
        """Generate the complete PDF document"""
        # Parse metadata and content
        metadata, content = self._parse_markdown_metadata(markdown_content)

        # Parse sections
        sections = self._parse_markdown_sections(content)

        # Extract title (first section or metadata)
        title = metadata.get('title', 'Technical Research Report')
        if not title and sections:
            title = sections[0]['title']

        # Create PDF
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.page_size,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=0.75*inch,
            bottomMargin=0.75*inch
        )

        # Build document
        self._add_cover_page(title, metadata)

        # Separate summary from main content if exists
        summary_section = None
        main_sections = sections

        for i, section in enumerate(sections):
            if section['title'].lower() in ['summary', 'executive summary', '요약', '개요']:
                summary_section = section
                main_sections = sections[:i] + sections[i+1:]
                break

        # Add summary if exists
        if summary_section:
            self._add_section(summary_section)
            self.story.append(PageBreak())

        # Add TOC
        # First collect all section titles for TOC
        for section in main_sections:
            self.toc_entries.append({'level': section['level'], 'title': section['title']})
        self._add_toc()

        # Reset TOC entries for actual content
        self.toc_entries = []

        # Add main content
        for section in main_sections:
            self._add_section(section)

        # Add acrostic if keywords provided
        if keywords:
            self.story.append(PageBreak())
            self._add_acrostic_section(keywords)

        # Add references if provided
        if references:
            self._add_references(references)

        # Build PDF
        doc.build(self.story)
        print(f"✅ PDF generated successfully: {self.output_path}")


def main():
    parser = argparse.ArgumentParser(
        description='Generate professional research PDF from markdown content'
    )
    parser.add_argument('input_file', help='Input markdown file path')
    parser.add_argument('-o', '--output', help='Output PDF file path (default: same as input with .pdf extension)')
    parser.add_argument('-k', '--keywords', help='Comma-separated keywords for 3-line acrostic', default='')
    parser.add_argument('-r', '--references', help='Path to references file (one per line)', default=None)
    parser.add_argument('--page-size', choices=['letter', 'a4'], default='letter', help='Page size (default: letter)')

    args = parser.parse_args()

    # Read input file
    input_path = Path(args.input_file)
    if not input_path.exists():
        print(f"Error: Input file not found: {args.input_file}")
        sys.exit(1)

    with open(input_path, 'r', encoding='utf-8') as f:
        markdown_content = f.read()

    # Determine output path
    output_path = args.output or str(input_path.with_suffix('.pdf'))

    # Parse keywords
    keywords = [k.strip() for k in args.keywords.split(',') if k.strip()] if args.keywords else []

    # Parse references
    references = []
    if args.references:
        ref_path = Path(args.references)
        if ref_path.exists():
            with open(ref_path, 'r', encoding='utf-8') as f:
                references = [line.strip() for line in f if line.strip()]

    # Determine page size
    page_size = A4 if args.page_size == 'a4' else letter

    # Generate PDF
    generator = ResearchPDFGenerator(output_path, page_size=page_size)
    generator.generate(markdown_content, keywords=keywords, references=references)


if __name__ == '__main__':
    main()
