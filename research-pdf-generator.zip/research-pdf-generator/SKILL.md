---
name: research-pdf-generator
description: Generate professional technical research reports in PDF format from markdown input. Use this skill when users provide research content (technical analysis, framework comparisons, library evaluations, etc.) and request a formatted PDF document. Triggers include requests like "create a PDF report", "generate a research document", or "format this as a professional PDF".
---

# Research PDF Generator

## Overview

Transform technical research content into professionally formatted PDF documents with a minimal, clean design. This skill automates the creation of structured research reports including cover pages, table of contents, executive summaries, 3-line acrostic poems based on keywords, and reference sections.

## When to Use This Skill

Use this skill when:
- Creating technical research reports (framework comparisons, library evaluations, technology assessments)
- Converting markdown research content into professional PDF documents
- Generating structured documentation with standardized sections
- Producing shareable research outputs with consistent formatting

## Quick Start

### Basic Workflow

1. **Receive research content** - User provides markdown-formatted research content
2. **Extract key information** - Identify title, keywords, references, and main sections
3. **Generate PDF** - Execute the generation script with appropriate parameters
4. **Deliver output** - Provide the generated PDF to the user

### Input Format

Accept research content in markdown format with optional YAML frontmatter:

```markdown
---
title: Your Research Title
subtitle: Optional Subtitle
author: Author Name
date: 2025-01-15
version: 1.0
---

# Executive Summary
Brief overview of findings...

# Introduction
Background and objectives...

# Methodology
How the research was conducted...

# Results
Findings and data...

# Conclusion
Summary and recommendations...
```

## Core Capabilities

### 1. Professional PDF Generation

Execute `scripts/generate_pdf.py` to transform markdown content into a formatted PDF:

```bash
python3 scripts/generate_pdf.py input.md -o output.pdf -k "keyword1,keyword2,keyword3" --page-size letter
```

**Parameters:**
- `input_file` - Path to markdown input file (required)
- `-o, --output` - Output PDF path (optional, defaults to input filename with .pdf extension)
- `-k, --keywords` - Comma-separated keywords for 3-line acrostic generation (optional)
- `-r, --references` - Path to references file with one reference per line (optional)
- `--page-size` - Page size: 'letter' or 'a4' (default: letter)

### 2. Document Structure

Generated PDFs include the following sections automatically:

**Cover Page:**
- Document title (large, centered)
- Subtitle (if provided)
- Metadata table with author, date, and version

**Table of Contents:**
- Auto-generated from markdown headings
- Hierarchical structure (supports H1, H2, H3)
- Clean, minimal design

**Executive Summary:**
- Automatically detected from sections titled "Summary", "Executive Summary", "요약", or "개요"
- Placed before main content
- Separate page

**Main Content:**
- Structured sections from markdown headings
- Support for code blocks, bullet lists, bold/italic formatting
- Professional typography with justified text

**3-Line Acrostic Poem:**
- Generated from provided keywords (up to 3)
- Creates memorable key insights
- Placed in dedicated "Key Insights" section

**References/Bibliography:**
- Numbered reference list
- Hanging indent formatting
- Professional citation style

### 3. Typography and Design

The generated PDFs use a **minimal/professional design**:

**Typography:**
- Headings: Helvetica Bold (clean, sans-serif)
- Body text: 11pt with 16pt leading for readability
- Code blocks: Monospace with subtle background color

**Color Scheme:**
- Primary text: Dark gray (#1a1a1a)
- Headings: Professional blue-gray (#2c3e50, #34495e)
- Code highlighting: Subtle pink (#c7254e) on light background (#f9f2f4)

**Layout:**
- 0.75" margins on all sides
- Justified body text for professional appearance
- Consistent spacing between sections
- Page breaks for major sections

## Usage Examples

### Example 1: Basic Research Report

```python
# User provides markdown content
markdown_content = """
---
title: FastAPI vs Flask Performance Analysis
author: Engineering Team
---

# Summary
Comparison of two popular Python frameworks...

# Introduction
## Background
Python web frameworks have evolved...
"""

# Save to file
with open('research.md', 'w') as f:
    f.write(markdown_content)

# Generate PDF
python3 scripts/generate_pdf.py research.md -k "FastAPI,Flask,Performance"
```

### Example 2: With References

Create a references file:

```text
Martin Fowler. "Microservices Architecture." martinfowler.com, 2024.
Real Python. "FastAPI Tutorial." realpython.com, 2024.
Official Flask Documentation. flask.palletsprojects.com, 2025.
```

Generate with references:

```bash
python3 scripts/generate_pdf.py research.md -k "API,Async,Python" -r references.txt --page-size a4
```

### Example 3: Complete Workflow

When a user says: *"I researched React vs Vue and wrote some notes. Can you create a professional PDF report?"*

**Steps:**

1. **Collect the content** - Ask the user to provide their research notes (or read from a file they specify)

2. **Structure the markdown** - If the content isn't already structured, help organize it:
   ```markdown
   ---
   title: React vs Vue: A Comparative Analysis
   subtitle: Framework Selection for Modern Web Development
   author: [User's Name]
   date: [Current Date]
   ---

   # Executive Summary
   [Extract or help write a summary]

   # Introduction
   [Organize their content]
   ...
   ```

3. **Extract keywords** - Identify 2-3 key terms (e.g., "React, Vue, Components")

4. **Collect references** - If they mention sources, create a references list

5. **Generate the PDF**:
   ```bash
   # Save content to file
   # Then run:
   python3 scripts/generate_pdf.py react_vs_vue_research.md \
     -o "React_vs_Vue_Report.pdf" \
     -k "React,Vue,Components" \
     -r references.txt
   ```

6. **Deliver** - Confirm the PDF was created and provide the file path

## Reference Files

### Example Research Template

See `references/example_research.md` for a complete example of properly formatted research content. This example demonstrates:

- YAML frontmatter structure
- Recommended section organization
- Code block formatting
- Bullet list usage
- Heading hierarchy

Load this reference when users need guidance on structuring their research content.

## Dependencies

The generation script requires:
- Python 3.7+
- reportlab (PDF generation library)
- markdown (markdown parsing)

Install with:
```bash
pip install reportlab markdown
```

## Tips for Best Results

1. **Clear structure** - Use markdown headings (#, ##, ###) consistently
2. **Frontmatter** - Include YAML metadata for professional cover page
3. **Keywords** - Choose 2-3 meaningful keywords for the acrostic section
4. **Code formatting** - Use triple backticks (```) for code blocks
5. **Lists** - Use `-` or `*` for bullet points (auto-formatted)
6. **Bold/Italic** - Use `**bold**` and `*italic*` for emphasis

## Troubleshooting

**Issue: Missing dependencies**
```bash
Error: reportlab is required
```
**Solution:** Install required libraries:
```bash
pip install reportlab markdown
```

**Issue: File not found**
```bash
Error: Input file not found: research.md
```
**Solution:** Verify the file path is correct and the file exists

**Issue: Malformed YAML**
```
# Content starts but metadata isn't recognized
```
**Solution:** Ensure YAML frontmatter is enclosed in `---` delimiters at the start of the file
